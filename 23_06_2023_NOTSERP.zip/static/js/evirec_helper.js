function closeViewPath(modalId) {

    $('#myModel_' + modalId).modal('hide'); //close nested modal

}