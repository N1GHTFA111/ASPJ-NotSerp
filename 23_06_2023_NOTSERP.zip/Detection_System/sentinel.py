# https://github.com/payloadbox
import datetime
import hashlib
import html
import os

import re
import secrets
import string
import random


def detect_path_traversal(url):
    # hex code: 0x2e=. 0x2f=/, 0x5c=\

    # check for common files like .htaccess, passwd, etc, shadow

    sus_chars = ['..', '../', '..\/', '%2e', '%2f', '%252e', '%252f', "%c0", "%ae",
                 "%af", "%uff0e", "%u2215", "%u2216", "./\/", ".\/", "%25c0", "%25ae", "%%"
                                                                                       "0x2e", "0x2f", "%%32", "%65",
                 "0x5c", "0x2e0x2e", ".htaccess", "htaccess", "passwd", "shadow", "boot.ini", ".asa"]
    for char in sus_chars:
        if char in url.lower():
            print("Path traversal detected")
            return True


# done
def detect_xss(user_input):
    sus_chars = ['<', 'href', 'src', 'javascript', '>', 'alert(', "<iframe", "<embed", "<input", "&gt", "onload",
                 "onpageshow",
                 "onfocus", "onmouseover", "&lt;", "&gt;", "%3e", "%3c", "prompt(", "()", "eval(", "`", "%60", "&lpar;",
                 "&rpar;", "&#x28;", "&#x29;", "&#40",
                 "&#41", "(alert", "=alert", ".source", '"al"+"ert', "/a", "/e", "(1)", '";', ".vibrate", "*{", ":url(",
                 ")}"]
    for char in sus_chars:
        if char in str(user_input).lower():
            return True


# https://github.com/swisskyrepo/PayloadsAllTheThings/tree/master/Upload%20Insecure%20Files


# https://github.com/swisskyrepo/PayloadsAllTheThings/tree/master/Server%20Side%20Template%20Injection


def calculate_md5(file_path):
    with open(file_path, 'rb') as file:
        md5_hash = hashlib.md5()
        while chunk := file.read(4096):
            md5_hash.update(chunk)
    return md5_hash.hexdigest()


def scan_file(file_path):
    md5_hash = calculate_md5(file_path)

    return False


def generate_secure_filename(extension):
    # Generate a random string to add uniqueness
    random_string = ''.join(random.choices(string.ascii_letters + string.digits, k=16))
    # Combine the safe filename, random string, and extension
    secure_filename = f"{random_string}.{extension}"
    return secure_filename


def generate_role_id():
    role_id = "ROLE_" + secrets.token_urlsafe(32)
    return role_id


def generate_auth_id():
    auth_id = "AUTH_" + secrets.token_urlsafe(32)
    return auth_id


def generate_transaction_id():
    tran_id = "TRANSACT_" + secrets.token_urlsafe(32)
    return tran_id

def generate_evirec_id():
    evirec_id = "EVIREC_" + secrets.token_urlsafe(32)
    return evirec_id


def generate_time_based_one_time_pass():
    one_time_pass = secrets.token_urlsafe(32)

    current_time = datetime.datetime.now()

    expiration_time = current_time + datetime.timedelta(minutes=1)

    one_time_pass_dict = {
        "one_time_pass": one_time_pass,
        "current time": current_time,
        "expiration time": expiration_time
    }

    return one_time_pass_dict


class FileChecker:
    def __init__(self):
        active = True

    @staticmethod
    def check_file_content(file_to_check):
        try:

            content = file_to_check.read()

            # Check for suspicious patterns or known signatures
            reverse_shell_pattern = r'(bash|cmd|nc|powershell|php|python|perl|rsh|ssh|telnet)\s*-c\s*'
            xss_script_pattern = r'<\s*script\b[^>]*>(.*?)<\s*/\s*script\s*>'

            if re.search(reverse_shell_pattern, content, re.IGNORECASE):
                print('Potential reverse shell code detected')
                return False

            if re.search(xss_script_pattern, content, re.IGNORECASE):
                print('Potential XSS script detected')
                return False

            print('File content is clean')
            return True
        except OSError:
            print('Unable to read the file')
            return False

    @staticmethod
    def check_file_type(file):
        # Read the first few bytes of the file

        bytes = file.read(4)

        # Check if the file is a PNG
        if bytes[:4] == b'\x89PNG':
            return True

        # Check if the file is a JPEG
        if bytes[:2] == b'\xff\xd8':
            return True

        # File type is unknown
        return False

    @staticmethod
    def is_allowed_file(filename):
        return filename.split(".")[1] in ['png', 'jpg', 'jpeg']

    @staticmethod
    def is_file_safe(file):
        if FileChecker.check_file_type(file) and FileChecker.is_allowed_file(file) and FileChecker.check_file_content(file):
            return True
        else:
            return False

    @staticmethod
    def check_file_metadata_comments(file):
        pass


class HTTPSecurityHeaders:

    def __init__(self):
        status = "Active"

    @staticmethod
    def generate_csp():
        csp = {
            'default-src': '\'self\'',
            'script-src': ['\'self\'', '\'unsafe-inline\'', 'https://cdn.jsdelivr.net/npm/', 'https://js.stripe.com/',
                           'https://hooks.stripe.com/', 'https://checkout.stripe.com/', 'https://www.google.com/', 'https://www.gstatic.com/', 'https://stripe.com/', 'https://ajax.googleapis.com/'],
            'style-src': ['\'self\'', '\'unsafe-inline\'', 'https://fonts.googleapis.com/', 'https://cdn.jsdelivr.net/', 'https://ajax.googleapis.com/'],
            'font-src': ['\'self\'', 'https://fonts.gstatic.com/', 'data:'],
            'img-src': ['\'self\'', 'data:', 'https://ajax.googleapis.com/'],
            'connect-src': ['\'self\'', 'https://fonts.gstatic.com/'],
            'object-src': '\'none\'',
            'base-uri': '\'self\'',
            'form-action': '\'self\'',
            'frame-ancestors': '\'none\'',
            'frame-src': [
                '\'self\'',
                'https://js.stripe.com/',
                'https://hooks.stripe.com/',
                'https://checkout.stripe.com/',
                'https://www.google.com/',
                'https://stripe.com/'
            ],
        }

        return csp


